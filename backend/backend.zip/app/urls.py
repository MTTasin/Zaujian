"""Storefront + admin API routes."""

from django.urls import include, path
from rest_framework.routers import APIRootView, DefaultRouter

from . import admin_api, finance_api, staff_api, views
from .permissions import AnyStaffPermission

router = DefaultRouter()
router.register(r"products", views.ProductViewSet, basename="product")
router.register(r"combos", views.ComboViewSet, basename="combo")


class _AdminAPIRootView(APIRootView):
    """The router's own index at /api/admin/ lists every admin endpoint. It
    inherits the project-wide AllowAny default otherwise, which hands a stranger
    a map of the admin surface — staff only."""

    permission_classes = [AnyStaffPermission]


class _AdminRouter(DefaultRouter):
    APIRootView = _AdminAPIRootView


# Admin (frontend panel) router
admin_router = _AdminRouter()
admin_router.register(r"products", admin_api.AdminProductViewSet, basename="admin-product")
admin_router.register(r"product-images", admin_api.AdminProductImageViewSet, basename="admin-product-image")
admin_router.register(r"product-specs", admin_api.AdminProductSpecViewSet, basename="admin-product-spec")
admin_router.register(r"product-fields", admin_api.AdminProductFieldViewSet, basename="admin-product-field")
admin_router.register(r"home-categories", admin_api.AdminHomeCategoryViewSet, basename="admin-home-category")
admin_router.register(r"leads", admin_api.AdminLeadViewSet, basename="admin-lead")
admin_router.register(r"capi-events", admin_api.AdminCapiEventViewSet, basename="admin-capi-event")
admin_router.register(r"colors", admin_api.AdminColorViewSet, basename="admin-color")
admin_router.register(r"toppings", admin_api.AdminToppingViewSet, basename="admin-topping")
admin_router.register(r"inside", admin_api.AdminInsideViewSet, basename="admin-inside")
admin_router.register(r"static", admin_api.AdminStaticViewSet, basename="admin-static")
admin_router.register(r"dupatta", admin_api.AdminDupattaViewSet, basename="admin-dupatta")
admin_router.register(r"config-images", admin_api.AdminConfigImageViewSet, basename="admin-configimage")
admin_router.register(r"combos", admin_api.AdminComboViewSet, basename="admin-combo")
admin_router.register(r"combo-images", admin_api.AdminComboImageViewSet, basename="admin-combo-image")
admin_router.register(r"combo-fields", admin_api.AdminComboFieldViewSet, basename="admin-combo-field")
admin_router.register(r"orders", admin_api.AdminOrderViewSet, basename="admin-order")
admin_router.register(r"order-tags", admin_api.AdminOrderTagViewSet, basename="admin-order-tag")
admin_router.register(r"custom-requests", admin_api.AdminCustomRequestViewSet, basename="admin-custom")
admin_router.register(r"gallery-photos", admin_api.AdminGalleryPhotoViewSet, basename="admin-gallery-photo")
admin_router.register(r"gallery-tags", admin_api.AdminGalleryTagViewSet, basename="admin-gallery-tag")
admin_router.register(r"chats", admin_api.AdminChatSessionViewSet, basename="admin-chat")
# Staff / moderators (owner only)
admin_router.register(r"staff", staff_api.AdminStaffViewSet, basename="admin-staff")
admin_router.register(r"audit-log", staff_api.AdminAuditLogViewSet, basename="admin-audit")
# Finance cash-book
admin_router.register(r"finance-categories", finance_api.AdminFinanceCategoryViewSet,
                      basename="admin-finance-category")
admin_router.register(r"suppliers", finance_api.AdminSupplierViewSet, basename="admin-supplier")
admin_router.register(r"expenses", finance_api.AdminExpenseViewSet, basename="admin-expense")
admin_router.register(r"credit-payments", finance_api.AdminCreditPaymentViewSet,
                      basename="admin-credit-payment")
admin_router.register(r"incomes", finance_api.AdminIncomeViewSet, basename="admin-income")
admin_router.register(r"buyers", finance_api.AdminBuyerViewSet, basename="admin-buyer")

urlpatterns = [
    path("", include(router.urls)),
    path("products/<slug:slug>/price/", views.price_lookup, name="product-price"),
    path("home/", views.home_view, name="home"),
    path("shop-info/", views.shop_info, name="shop-info"),
    # Cart
    path("cart/", views.cart_view, name="cart"),
    path("cart/add/", views.cart_add, name="cart-add"),
    path("cart/<int:item_id>/", views.cart_item, name="cart-item"),
    # Checkout / orders / payment (public tracking by uid)
    path("checkout/", views.checkout, name="checkout"),
    path("orders/<str:uid>/", views.order_detail, name="order-detail"),
    path("orders/<str:uid>/payment/", views.order_payment, name="order-payment"),
    # Custom requests
    path("custom-request/", views.custom_request, name="custom-request"),
    # Chatbot (public)
    path("chat/send/", views.chat_send, name="chat-send"),
    path("chat/poll/", views.chat_poll, name="chat-poll"),
    # Gallery (public)
    path("gallery/", views.gallery_index, name="gallery-index"),
    path("gallery/<slug:slug>/", views.gallery_detail, name="gallery-detail"),
    # Visitor tracking + nudge (public)
    path("nudge-event/", views.nudge_event, name="nudge-event"),
    # Analytics beacon (public, batched, 204-always)
    path("t/", views.track, name="track"),
    # Steadfast pushes parcel status here (Bearer-token protected, not admin auth)
    path("steadfast/webhook/", views.steadfast_webhook, name="steadfast-webhook"),
    # ---- Admin panel API ----
    path("admin/login/", admin_api.admin_login, name="admin-login"),
    path("admin/me/", admin_api.admin_me, name="admin-me"),
    path("admin/dashboard/", admin_api.admin_dashboard, name="admin-dashboard"),
    path("admin/analytics/", admin_api.admin_analytics, name="admin-analytics"),
    path("admin/analytics/live/", admin_api.admin_analytics_live, name="admin-analytics-live"),
    path("admin/analytics/overview/", admin_api.admin_analytics_overview,
         name="admin-analytics-overview"),
    path("admin/chat-unread/", admin_api.admin_chat_unread, name="admin-chat-unread"),
    path("admin/push-key/", admin_api.admin_push_key, name="admin-push-key"),
    path("admin/push-subscribe/", admin_api.admin_push_subscribe, name="admin-push-subscribe"),
    path("admin/bot-config/", admin_api.admin_bot_config, name="admin-bot-config"),
    path("admin/orders/manual/", admin_api.admin_create_order, name="admin-order-manual"),
    path("admin/fraud-check/", admin_api.admin_fraud_check, name="admin-fraud-check"),
    path("admin/site-settings/", admin_api.admin_site_settings, name="admin-site-settings"),
    path("admin/finance/summary/", finance_api.finance_summary, name="admin-finance-summary"),
    path("admin/finance/meta/", finance_api.finance_meta, name="admin-finance-meta"),
    path("admin/finance/ledger/", finance_api.finance_ledger, name="admin-finance-ledger"),
    path("admin/finance/order-search/", finance_api.finance_order_search,
         name="admin-finance-order-search"),
    path("admin/finance/order/<int:pk>/", finance_api.order_finance,
         name="admin-finance-order"),
    path("admin/", include(admin_router.urls)),
]
