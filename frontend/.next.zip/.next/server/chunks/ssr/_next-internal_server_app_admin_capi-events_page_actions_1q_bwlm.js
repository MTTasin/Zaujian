module.exports=[94641,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_capi-events_page_actions_1q_bwlm.js.map