module.exports=[12850,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_bot_page_actions_1ubabnj.js.map