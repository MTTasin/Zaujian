1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/0jycqm0cdw-80.js","/_next/static/chunks/1t67qk22867r1.js","/_next/static/chunks/1tixat98om2ln.js","/_next/static/chunks/1-8s9_t85wwr4.js"],"default"]
3:I[37457,["/_next/static/chunks/0jycqm0cdw-80.js","/_next/static/chunks/1t67qk22867r1.js","/_next/static/chunks/1tixat98om2ln.js","/_next/static/chunks/1-8s9_t85wwr4.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"uD-xNC9WN-4HnAXPGh4Qa"}
