1:"$Sreact.fragment"
2:I[92825,["/_next/static/chunks/0jycqm0cdw-80.js","/_next/static/chunks/1t67qk22867r1.js","/_next/static/chunks/1tixat98om2ln.js","/_next/static/chunks/1-8s9_t85wwr4.js"],"ClientSegmentRoot"]
3:I[88760,["/_next/static/chunks/0jycqm0cdw-80.js","/_next/static/chunks/1t67qk22867r1.js","/_next/static/chunks/1tixat98om2ln.js","/_next/static/chunks/1-8s9_t85wwr4.js","/_next/static/chunks/2jv7lanckw602.js"],"default"]
4:I[39756,["/_next/static/chunks/0jycqm0cdw-80.js","/_next/static/chunks/1t67qk22867r1.js","/_next/static/chunks/1tixat98om2ln.js","/_next/static/chunks/1-8s9_t85wwr4.js"],"default"]
5:I[37457,["/_next/static/chunks/0jycqm0cdw-80.js","/_next/static/chunks/1t67qk22867r1.js","/_next/static/chunks/1tixat98om2ln.js","/_next/static/chunks/1-8s9_t85wwr4.js"],"default"]
0:{"rsc":["$","$1","c",{"children":[[["$","script","script-0",{"src":"/_next/static/chunks/2jv7lanckw602.js","async":true}]],["$","$L2",null,{"Component":"$3","slots":{"children":["$","$L4",null,{"parallelRouterKey":"children","template":["$","$L5",null,{}]}]},"serverProvidedParams":{"params":{},"promises":["$@6"]}}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"uD-xNC9WN-4HnAXPGh4Qa"}
6:"$0:rsc:props:children:1:props:serverProvidedParams:params"
